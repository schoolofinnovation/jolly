 <main>
 @livewire('slider-component')
 
<!--Mobile View-->
    <section class="ImageBackground ImageBackground--overlay v-align-parent u-height350 mobileview" data-overlay="5">
        <div class="ImageBackground__holder" style="background-image: url({{asset('img/expo.jpg')}});">
            <img src="{{asset('img/expo.jpg')}}" alt="">
        </div>
        <div class="v-align-child">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-white text-center">
                        <div class="anbc">Nov  25 - 28, 2022<span>Govt. College Ground, Jammu</span>
                         <center><a class="btn btn-primary text-uppercase u-MarginBottom10 u-LetterSpacing2" href="#">Register Now</a></center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</section>
<!-- End Mobile View-->
	
<!--schedule short info start-->
    <section class="bg-primary bg-primary--gradient u-PaddingTop50 u-PaddingBottom50 ban">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-6 ">
                    <div class="media u-OverflowVisible">
                        <div class="media-left">
                            <div class="Thumb">
                                <i class="Icon icon-map-marker Icon--32px" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="media-body">
                            <h4 class="u-MarginTop0 u-MarginBottom5 u-Weight700">Govt. College Ground, Jammu</h4>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 u-MarginBottom15">
                    <div class="media u-OverflowVisible">
                        <div class="media-left">
                            <div class="Thumb">
                                <i class="Icon Icon-clock Icon--32px" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="media-body">
                            <h4 class="u-MarginTop0 u-MarginBottom5 u-Weight700">Nov 25 - 28, 2022</h4>
                            <small class="u-MarginBottom15">09:00 AM - 06:00 PM </small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 ">
                    <div class="media u-OverflowVisible">
                        <div class="media-left">
                            <div class="Thumb">
                                <i class="Icon Icon-sitemap Icon--32px" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="media-body">
                            <h4 class="u-MarginTop0 u-MarginBottom5 u-Weight700">5000+ Potential Investors  </h4>
                            <small>150+ Brands Ready to Partner</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="media u-OverflowVisible">
                        <div class="media-left">
                            <div class="Thumb">
                                <i class="Icon Icon-wine Icon--32px" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div class="media-body">
                            <h4 class="u-MarginTop0 u-MarginBottom5 u-Weight700">Free Lunch & Snacks</h4>
                            <small>Don't miss it</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--schedule short info end-->

<!--about start-->
    <section class="abouSec u-PaddingTop60 u-PaddingBottom60  u-xs-PaddingBottom30 u-xs-PaddingTop10 u-sm-PaddingTop50 u-MarginBottom0 u-zIndex10 position-relative">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center u-MarginBottom30 u-xs-MarginBottom30 u-sm-MarginBottom30 M-MrgBtm10">
                    <h1 class="u-MarginTop0 u-sm-MarginTop30 u-Weight700 M-MrgBtm10 h1"><center>About The Event</center></h1>
                    <div class="Split Split--height2"></div>
                    
                </div>
                <div class="row text-center">
                <div class="col-xs-12 col-sm-12 col-md-12">
                <p class="u-MarginBottom30 u-xs-MarginBottom30 fro2017 h3"><strong>Archexpo 2022 Jammu, India </strong>
               
               <br>124th National Interior & Exterior Retail Real Estate Event</p>
        <p class="u-MarginBottom30 u-xs-MarginBottom30 fro2017">
        India's premier and most trusted Business &amp; Tradeshow is back in Chennai to provide a platform for highly evolved prospects, 
        qualified investors, entrepreneurs from across India, neighbouring countries and delegations from other parts of the world. Meet 
        face-to-face for some of the most accomplished Business Ideas and learn more about India &amp; it’s fast growing MSME industry.</p>

                    
                    </div>
                    <div class="u-MarginTop50">
                        <center><a class="btn btn-primary text-uppercase u-MarginBottom10 u-LetterSpacing2" href="#">Read More</a></center>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--about end-->

<!--features start-->
    <section class="u-BoxShadow40">
        <div class="ImageBlock ImageBlock--switch">
            <div class="ImageBlock__image col-md-6 col-sm-4">
                <div class="ImageBackground ImageBackground--overlay" data-overlay="0">
                    <div class="ImageBackground__holder" style="background-image: url({{asset('img/expo.jpg')}});">
                        <img src="{{asset('img/expo.jpg')}}" alt="">
                    </div>
                </div>
            </div>
            <div class="container exbCont">
                <div class="row">
                    <div class="col-md-5 col-sm-7 exbFull">
                        <h1 class="u-MarginTop0 u-MarginBottom0 u-Weight700 h1">The Decor Show</h1>
                        <h3 class="u-MarginTop10 text-gray">124th National Startups & Retail Show</h3>
                        <p>Investors, aspiring entrepreneur and business owners here is your chance to grab the lifetime opportunity with FROEXPO 2022, an initiative of Franchise India Holdings Limited. Franchise India Exhibitions' is honored to convey that our exhibitions have benefitted over 370,000 business investors with over 500 shows held both in India and overseas. In 2019 alone, we assisted over 1000 companies and over 1,75,000 visitors. </p>
      <div class="u-MarginTop20 tct">
                        <a class="btn btn-primary text-uppercase u-MarginBottom10 u-LetterSpacing2" href="https://www.franchiseindia.com/fro/2022/chennai/exhibition_booking_form.php">Book your Stall</a>
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="ImageBlock">
            <div class="ImageBlock__image col-md-6 col-sm-4">
                <div class="ImageBackground ImageBackground--overlay" data-overlay="5">
                    <div class="ImageBackground__holder" style="background-image: url({{asset('img/awards.jpg')}});">
                       <img src="{{asset('img/awards.jpg')}}" alt="">
                    </div>
                </div>
            </div>
            <div class="container testimonials">
                <div class="row">
                    <div class="col-md-5 col-sm-7 exbFull">
                       <h1 class="u-MarginTop0 u-MarginBottom0 u-Weight700 h1">Archex Expo</h1>
                        <h3 class="u-MarginTop10 text-gray">India's Top Most Awards in Franchise &amp; Retail</h3>
                        <p>Franchise &amp; Retail Awards 2022 are India's Topmost Honour in Franchising &amp; Retailing. FRO Awards 2022 highlights those remarkable organizations that have, demonstrated that franchising success is more than the sum of its parts. The Franchise &amp; Retail Awards put standards, ethics and best practice at the top of their agenda. Through positive recognition of those that lead the way, the awards are seen as the industry's top accolade.</p>
      <div class="u-MarginTop20 tct">
                       <a class="btn btn-primary text-uppercase u-MarginBottom10 u-LetterSpacing2" href="https://www.franchiseindia.com/fro/2021/mumbai/awards/" target="_blank">View More</a>
                    </div>
                    </div>
                </div>
            </div>
        </div>


      <div class="ImageBlock ImageBlock--switch">
            <div class="ImageBlock__image col-md-6 col-sm-4">
                <div class="ImageBackground ImageBackground--overlay" data-overlay="5">
                    <div class="ImageBackground__holder" style="background-image: url({{asset('img/awards.jpg')}});">
                        <img src="{{asset('img/awards.jpg')}}" alt=""/>
                    </div>
                </div>
            </div>
            <div class="container exbCont">
                <div class="row">
                    <div class="col-md-5 col-sm-7 exbFull">
                        <h1 class="u-MarginTop0 u-MarginBottom0 u-Weight700 h1">MacEngin Expo</h1>
                        <h3 class="u-MarginTop10 text-gray">India's Top Most Awards in Franchise & Retail</h3>
                        <p>Franchise & Retail Awards 2022 are India's Topmost Honour in Franchising & Retailing. FRO Awards 2022 highlights those remarkable organizations that have, demonstrated that franchising success is more than the sum of its parts. The Franchise & Retail Awards put standards, ethics and best practice at the top of their agenda. Through positive recognition of those that lead the way, the awards are seen as the industry's top accolade.</p>
       <div class="u-MarginTop20 tct">
                        <a class="btn btn-primary text-uppercase u-MarginBottom10 u-LetterSpacing2" href="https://www.franchiseindia.com/fro/2021/mumbai/awards/" target="_blank">View More</a>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--features end--> 

<!-- our Exhibitors -->
    <section id="sponsors" class="u-PaddingBottom60  u-xs-PaddingBottom30 u-xs-PaddingTop30  u-MarginBottom0 u-zIndex10 grey-bg">
        <div class="row text-center u-MarginBottom30">
            <div class="col-md-8 col-md-offset-2">
                <br><br>
                <h1 class="u-MarginTop5 u-MarginBottom10 u-Weight700 u-sm-PaddingTop30 M-MrgBtm10 h1">Our Exhibitors </h1>
                <div class="Split Split--height2"></div>
            </div>
        </div>
    
        <div class="container">
            <div class="sponsors">
                <div class="nbs-flexisel-container">
                <div class="nbs-flexisel-inner">
                <ul id="exb" class="nbs-flexisel-ul" style="left: -164.286px;">
                    
                    <li  class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/smily.gif')}}" alt="">
                    <img src="{{asset('img/uclean.gif')}}" alt="">
                    </span>
                    </li>
                    <li  class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/teology.gif')}}" alt="">
                    <img src="{{asset('img/ast.gif')}}" alt="">
                    </span>
                    </li>
                    <li  class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/litt.gif')}}" alt="">
                    <img src="{{asset('img/peepall.gif')}}" alt="">
                    </span>
                    </li>
                    <li  class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/a2.gif')}}" alt="">
                    <img src="{{asset('img/go.gif')}}" alt="">
                    </span>
                    </li>
                    <li  class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/pri.gif')}}" alt="">
                    <img src="{{asset('img/vib.gif')}}" alt="">
                    </span>
                    </li>
                    <li  class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/metro.gif')}}" alt="">
                    <img src="{{asset('img/lassi.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/5k-network.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/vai.gif')}}" alt="">
                    <img src="{{asset('img/better.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/gfo.gif')}}" alt="">
                    <img src="{{asset('img/prestige.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/prorganiq.gif')}}" alt="">
                    <img src="{{asset('img/remax.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/smily.gif')}}" alt="">
                    <img src="{{asset('img/uclean.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/teology.gif')}}" alt="">
                    <img src="{{asset('img/ast.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/litt.gif')}}" alt="">
                    <img src="{{asset('img/peepall.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/a2.gif')}}" alt="">
                    <img src="{{asset('img/go.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/pri.gif')}}" alt="">
                    <img src="{{asset('img/vib.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/metro.gif')}}" alt="">
                    <img src="{{asset('img/lassi.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/5k-network.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/vai.gif')}}" alt="">
                    <img src="{{asset('img/better.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/gfo.gif')}}" alt="">
                    <img src="{{asset('img/prestige.gif')}}" alt="">
                    </span>
                    </li>
                    <li class="nbs-flexisel-item" style="width: 164.286px;"> 
                    <span class="exhibitor">
                    <img src="{{asset('img/prorganiq.gif')}}" alt="">
                    <img src="{{asset('img/remax.gif')}}" alt="">
                    </span>
                    </li>
                
                </ul>
            
            </div>
            
            <div class="nbs-flexisel-nav-left" style="visibility: visible; top: 101px;">
            </div>
            <div class="nbs-flexisel-nav-right" style="visibility: visible; top: 101px;">
            </div>
            </div>
            </div>
            <br> <br>
            <div class="u-MarginTop20">
                <center><a class="btn btn-primary text-uppercase u-MarginBottom10 u-LetterSpacing2" href="https://www.franchiseindia.com/fro/2022/chennai/exhibitors.php" target="_blank">View All Exhibitors</a></center>
            </div>
        </div>
    </section>
<!-- End our Exhibitors -->

<!-- start Speaker-->
    <section class="u-PaddingTop60 u-PaddingBottom60 u-xs-PaddingBottom30 u-xs-PaddingTop30 u-MarginBottom0 spkbg u-zIndex10 position-relative">
        <div class="container ">
            <div class="row">
                <div class="col-md-12 text-center u-MarginBottom30 u-xs-MarginBottom30 u-sm-MarginBottom30"> 
                    <!--<small class="text-uppercase u-LetterSpacing1">Our</small>-->
                    <h1 class="u-MarginTop5 u-MarginBottom10 u-Weight700 h1">Speakers</h1>
                    <!--<h1 class="u-MarginTop5 u-MarginBottom10 u-Weight700">Previous Speakers</h1>-->
                    <div class="Split Split--height2"></div>
                </div>
            </div>
                <ul class="nbs-flexisel-ul my-Slider2">
                    <li class="nbs-flexisel-item">
                        <a href="https://www.franchiseindia.com/fro/2021/bengaluru/vikas.php">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/vikas.jpg')}}" alt="vikas" class="SpkImg">
                        </div>

                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Vikas Sarda</h5>
                        <span class="SpkDes">Chief Financial Officer, Unitus Capital</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a href="#">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/farman.jpg')}}" alt="farman" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Farman Beig</h5>
                        <span class="SpkDes">Co-founder &amp; CEO, Wat-a-Burger</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a href="#">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/siddarthk.jpg')}}" alt="siddarthk" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Siddarth Kukreja</h5>
                        <span class="SpkDes">AGM - Real Estate, Reliance Vision Express</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a>
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/bhuvanesh.jpg')}}" alt="bhuvanesh" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Bhuvanesh Mendiratta </h5>
                        <span class="SpkDes">Vice President P&amp;L, Miraj Entertainment</span>
                        </div>
                        </div>
                        </a>
                    </li>
                    
                    <li class="nbs-flexisel-item">
                        <a href="https://www.franchiseindia.com/fro/2021/bengaluru/pallav.php">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/pallav.jpg')}}" alt="indraneel" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Pallav Atreja</h5>
                        <span class="SpkDes">Head Retail, Montblanc</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a href="https://www.franchiseindia.com/fro/2021/bengaluru/karthick.php">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/karthick.jpg')}}" alt="karthick" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Dr.Karthick kumar Chinnaraj </h5>
                        <span class="SpkDes">Founder &amp; Managing Director of 5K Car Care Pvt Ltd</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a href="https://www.franchiseindia.com/fro/2021/bengaluru/chetan.php">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/chetan.jpg')}}" alt="chetan" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Chetan Kasim </h5>
                        <span class="SpkDes">Co-Founder &amp; CEO at Valenta BPO Solutions</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a href="https://www.franchiseindia.com/fro/2021/bengaluru/kg.php">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/kg.jpg')}}" alt="kg" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">K G GEORGE </h5>
                        <span class="SpkDes">Senior VP Retail, TKK Prestige</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a href="https://www.franchiseindia.com/fro/2021/bengaluru/bhuvan.php">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/bhuvan.jpg')}}" alt="bhuvan" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Bhuvan Bhasin</h5>
                        <span class="SpkDes">Asst Vice President - Retail &amp; Mall Operations, Park Square Mall</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a href="">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/shashank.jpg')}}" alt="bhuvan" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Shashank Singh</h5>
                        <span class="SpkDes">CEO &amp; Director, Capsicum Kitchens &amp; Wardrobes</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a href="https://www.franchiseindia.com/fro/2021/bengaluru/senthil.php">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/senthil.jpg')}}" alt="bhuvan" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Senthil Kumar</h5>
                        <span class="SpkDes">COO at YLG India</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a>
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/ankur.jpg')}}" alt="bhuvan" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Ankur Khaitan</h5>
                        <span class="SpkDes">Senior Director in Consumer &amp; Retail sector at KPMG</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a>
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/abhishek1.jpg')}}" alt="bhuvan" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Abhishek Raj</h5>
                        <span class="SpkDes">COO, Lacoste India</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a href="https://www.franchiseindia.com/fro/2021/bengaluru/ritesh.php">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/ritesh.jpg')}}" alt="Ritesh" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Ritesh Jain</h5>
                        <span class="SpkDes">Vice President, Ecommerce Business, Wonderchef</span>
                        </div>
                        </div>
                        </a>
                    </li>

                    <li class="nbs-flexisel-item">
                        <a href="https://www.franchiseindia.com/fro/2021/bengaluru/ritesh.php">
                        <div class="SpkSec deeede">
                        <div class="SpkImgSec">
                        <img src="{{asset('img/varun.jpg')}}" alt="Ritesh" class="SpkImg">
                        </div>
                        <div class="SpkContSec">
                        <h5 class="SpkTitle">Varun Gupta</h5>
                        <span class="SpkDes">Founder &amp; Director, Zorgers</span>
                        </div>
                        </div>
                        </a>
                    </li>

                </ul>
        </div>
    </section>
<!-- end speaker-->

<!--Gallery start-->
    <div class="container js-PortfolioWrapper u-PaddingTop60 u-xs-PaddingTop30 u-PaddingBottom60 u-xs-PaddingBottom30 m-hide">
        <div class="row text-center u-MarginBottom30">
            <div class="col-md-8 col-md-offset-2">
                <h1 class="u-MarginTop5 u-MarginBottom10 u-Weight700 h1">Our Gallery</h1>
                <div class="Split Split--height2"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="js-Portfolio portfolio-grid portfolio-gallery grid-3 gutter" style="position: relative; height: 451.562px;">
                    <div class="portfolio-item cat1 cat3 cat5" style="position: absolute; left: 0px; top: 0px;">
                        <a href="{{asset('img/01.jpg')}}" class="portfolio-image popup-gallery">
                            <img src="{{asset('img/01.jpg')}}" alt="">
                            <div class="portfolio-hover-title">
                                <div class="portfolio-content">
                                      <h4><span class="Icon Icon-magnifying-glass"></span></h4>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="portfolio-item cat2 cat3 cat4" style="position: absolute; left: 293px; top: 0px;">
                        <a href="{{asset('img/02.jpg')}}" class="portfolio-image popup-gallery">
                            <img src="{{asset('img/02.jpg')}}" alt="">
                            <div class="portfolio-hover-title">
                                <div class="portfolio-content">
                                     <h4><span class="Icon Icon-magnifying-glass"></span></h4>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="portfolio-item cat1 cat2 cat3" style="position: absolute; left: 586px; top: 0px;">
                        <a href="{{asset('img/03.jpg')}}" class="portfolio-image popup-gallery">
                            <img src="{{asset('img/03.jpg')}}" alt="">
                            <div class="portfolio-hover-title">
                                <div class="portfolio-content">
                                    <h4><span class="Icon Icon-magnifying-glass"></span></h4>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="portfolio-item cat1 cat4" style="position: absolute; left: 879px; top: 0px;">
                        <a href="{{asset('img/04.jpg')}}" class="portfolio-image popup-gallery">
                            <img src="{{asset('img/04.jpg')}}" alt="">
                            <div class="portfolio-hover-title">
                                <div class="portfolio-content">
                                      <h4><span class="Icon Icon-magnifying-glass"></span></h4>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="portfolio-item cat3 cat5" style="position: absolute; left: 0px; top: 225px;">
                        <a href="{{asset('img/05.jpg')}}" class="portfolio-image popup-gallery">
                            <img src="{{asset('img/05.jpg')}}" alt="">
                            <div class="portfolio-hover-title">
                                <div class="portfolio-content">
                                      <h4><span class="Icon Icon-magnifying-glass"></span></h4>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="portfolio-item cat4 cat5" style="position: absolute; left: 293px; top: 225px;">
                        <a href="{{asset('img/06.jpg')}}" class="portfolio-image popup-gallery">
                            <img src="{{asset('img/06.jpg')}}" alt="">
                            <div class="portfolio-hover-title">
                                <div class="portfolio-content">
                                      <h4><span class="Icon Icon-magnifying-glass"></span></h4>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="portfolio-item cat1 cat3 cat5" style="position: absolute; left: 586px; top: 225px;">
                        <a href="{{asset('img/07.jpg')}}" class="portfolio-image popup-gallery">
                            <img src="{{asset('img/07.jpg')}}" alt="">
                            <div class="portfolio-hover-title">
                                <div class="portfolio-content">
                                   <h4><span class="Icon Icon-magnifying-glass"></span></h4>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="portfolio-item cat1 cat3 cat5" style="position: absolute; left: 879px; top: 225px;">
                        <a href="{{asset('img/08.jpg')}}" class="portfolio-image popup-gallery">
                            <img src="{{asset('img/08.jpg')}}" alt="">
                            <div class="portfolio-hover-title">
                                <div class="portfolio-content">
                                          <h4><span class="Icon Icon-magnifying-glass"></span></h4>
                                    
                                </div>
                            </div>
                        </a>
                    </div>
                </div> 
            </div>
			<!--<div class="u-MarginTop20">
                        <center><a class="btn btn-primary text-uppercase u-MarginBottom10 u-LetterSpacing2" href="#">View More</a></center>
                    </div>-->
        </div>
    </div>
<!--Gallery end-->
  
<!--testimonal start-->
    <section class="testimonial">
        <div class="ImageBlock ImageBlock--switch">
         <div class="container">
            <div class="row">
                <div class="col-sm-12">
                <h1 class="u-MarginTop5 u-MarginBottom10 u-Weight700 text-center h1">WHAT BRANDS SAY</h1>
                <div class="Split Split--height2 text-center"></div>
                    <div class="seprator"></div>
                        <div  class="carousel slide" data-ride="carousel">
                            <!-- Wrapper for slides -->
                            <div class="carousel-inner my-Slider1">
                                <div class="item">
                                    <div class="row" style="padding: 20px">
                                        <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                                        <p class="testimonial_para">"FROEXPO Provides A Very Good Platform For Business Expansion By Bring Under One Roof All The Types And City/ Region Specific Enterprenuer Who Are Either Already In Or Looking For..."</p>
                                        <div class="row">
                                        
                                            <div>
                                            <h4><strong>Classic Polo</strong></h4>
                                        
                                        </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="item">
                                    <div class="row" style="padding: 20px">
                                        <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                                        <p class="testimonial_para">"Franchise India is the perfect platform, for building strategic franchising ties. They have an excellent client side experience backed by an energetic, and self motivated team capable of building an interactive platform; bringing together..."</p>
                                        <div class="row">
                                        
                                            <div>
                                            <h4><strong>Diva'ni</strong></h4>
                                        
                                        </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="item">
                                    <div class="row" style="padding: 20px">
                                        <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                                        <p class="testimonial_para">"FRO Chennai show was very well organised. FRO Expo has helped us in expanding our franchising network. There were good brands present at the show. Looking forward to the Delhi expo."</p>
                                        <div class="row">
                                        
                                            <div>
                                            <h4><strong>Diva'ni</strong></h4>
                                        
                                        </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="item active">
                                    <div class="row" style="padding: 20px">
                                        <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                                        <p class="testimonial_para">"It was a great experience being a part of FRO. We not only met quality potential investors but it was also a great networking platform and I am looking forward to be a part of you again."</p>
                                        <div class="row">
                                        
                                            <div>
                                            <h4><strong>Diva'ni</strong></h4>
                                        
                                        </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="item">
                                    <div class="row" style="padding: 20px">
                                        <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                                        <p class="testimonial_para">"Franchising India has been consistently focused on discovering winners and have contributed tremendously to the growth of the franchising culture in the country. It is a pioneer in it's field and Gold's Gym is pleased to be associated with them."</p>
                                        <div class="row">
                                        
                                            <div>
                                            <h4><strong>Diva'ni</strong></h4>
                                        
                                        </div>
                                        </div>
                                    </div>
                                </div>
                                    
                                <div class="item">
                                    <div class="row" style="padding: 20px">
                                        <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                                        <p class="testimonial_para">"Despite of long weekend FRO Chennai was a wonderful event. The quality enquiries were generated at the show. The show was very well organised. Wishing Franchise India and Team all the best!"</p>
                                        <div class="row">
                                        
                                            <div>
                                            <h4><strong>Diva'ni</strong></h4>
                                        
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                </div>
            </div>
         </div>
        </div>
   </section>
<!--testimonal end-->  

<!--partner end-->
  <div class="sponsors padSec" style="padding: 40px 0px;">
    <div class="container-fluid">
      <div class="spon-top">
        
        <div class="row text-center u-MarginBottom30">
            <div class="col-md-8 col-md-offset-2">
                <h1 class="u-MarginTop5 u-MarginBottom10 u-Weight700 h1">Our <span>Partners</span></h1>
                <div class="Split Split--height2"></div>
            </div>
        </div>

        <div class="row"> 
          <ul class="setul my-Slider3">
                <li>
                 <div class="prtTitle">Title Partner</div>
                  <a href="https://www.franchiseindia.in/" target="_blank">
                      <img src="https://www.franchiseindia.com/fro/2021//bengaluru/assets/imgs/partners/fivek.jpg" alt="Organised By Franchise India"></a>        
                </li>

                <li>
                    <div class="prtTitle">Title Partner </div>
                    <a href="https://www.franchiseindia.in/" target="_blank"><img src="{{asset('img/title-partner.gif')}}" alt="Supporting Portal Franchise Bangladesh"></a> 
                </li>

                <li>
                    <div class="prtTitle">Associate Sponsor </div>
                    <a href="https://www.remax.in/" target="_blank"><img src="{{asset('img/remax.jpg')}}" alt="Supporting Portal Franchise Bangladesh"></a> 
                </li>

                <li>
                    <div class="prtTitle">Supported By </div>
                    <a><img src="https://www.franchiseindia.com/fro/2021/bengaluru/assets/imgs/partners/cedok.jpg" alt="Supporting Portal Franchise Bangladesh"></a> 
                </li>
            
                <li>
                        <div class="prtTitle">Associate Sponsor</div>
                        <a href="https://www.franchiseindia.in/" target="_blank"><img src="https://www.franchiseindia.com/fro/2021/bengaluru/assets/imgs/partners/ver.jpg" alt="Organised By Franchise India"></a>  
                </li>
                
                <li>
                        <div class="prtTitle">Associate Sponsor</div>
                        <a href="https://www.franchiseindia.in/" target="_blank"><img src="https://www.franchiseindia.com/fro/2021/bengaluru/assets/imgs/partners/val.jpg" alt="Organised By Franchise India"></a>  
                </li>

                <li>
                        <div class="prtTitle">Associate Sponsor</div>
                        <a><img src="{{asset('img/zor.jpg')}}" alt="Organised By Franchise India"></a>
                </li>
                
                <li>
                    <div class="prtTitle">Associate Sponsor</div>
                    <a><img src="https://www.franchiseindia.com/fro/2021/bengaluru/assets/imgs/partners/champ.jpg" alt="bengaluru"> </a>
                </li>
            
                <li>
                <div class="prtTitle">Associate Sponsor </div>
                <a href="https://uclean.in/" target="_blank"><img src="{{asset('img/uclean.jpg')}}" alt="Supporting Portal Franchise Bangladesh"> </a>
                </li>

                <li>
                <div class="prtTitle">Sponsor</div>
                <a href="https://www.businessex.com/" target="_blank"><img src="{{asset('img/business_Ex.jpg')}}" alt="Supporting Portal Franchise Bangladesh"> </a>
                </li>
            
                <li>
                <div class="prtTitle">Sponsor</div>
                <a href="https://www.actioncoach.com/" target="_blank"><img src="{{asset('img/actioncoach.jpg')}}" alt="Supporting Portal Franchise Bangladesh"> </a>
                </li>
                
                <li>
                        <div class="prtTitle">Organised by</div>
                <a href="https://www.francorp.in/" target="_blank"><img src="{{asset('img/fihl.png')}}" alt="Knowledge Partner Francorp"></a>
                </li>

                <li>
                        <div class="prtTitle">Knowledge Partner</div>
                <a href="https://www.francorp.in/" target="_blank"><img src="{{asset('img/francorp.gif')}}" alt="Knowledge Partner Francorp"></a>
                </li>

                <li>
                        <div class="prtTitle">Official Portal</div>
                        <a href="https://www.franchiseindia.com/" target="_blank"><img src="{{asset('img/franchise-india.gif')}}" alt="Organised By Franchise India"></a>
                </li>

                <li>
                    <div class="prtTitle">Official Podcast Partner</div>
                <a href="https://www.franchiseindia.com/top100franchise2021magazine/" target="_blank"><img src="{{asset('img/tfw.gif')}}" alt="Official Magazine Franchising World"></a>
                </li>

                <li>
                <div class="prtTitle">Partner Portal</div>
                <a href="https://www.indianretailer.com/" target="_blank"><img src="{{asset('img/indianretailer.jpg')}}" alt="Supporting Portal Franchise Bangladesh"> </a>
                </li>
                
                <li>
                <div class="prtTitle">Partner Portal</div>
                <a href="https://www.licenseindia.com/" target="_blank"><img src="{{asset('img/licenseindia.jpg')}}" alt="Supporting Portal Franchise Bangladesh"></a>
                </li>

                <li>
                        <div class="prtTitle">Nepal Associate</div>
                <img src="https://www.franchiseindia.com/fro/2021/delhi/assets/imgs/partners/franchise-nepal.png" alt="Supporting Portal Franchise Nepal">
                </li>
                
                <li>
                        <div class="prtTitle">Bangladesh Associate</div>
                <img src="https://www.franchiseindia.com/fro/2021/delhi/assets/imgs/partners/franchise-bangladesh.png" alt="Supporting Portal Franchise Bangladesh">
                </li>
                
                <li>
                        <div class="prtTitle">Partner Portal</div>
                <a href="https://dealer.franchiseindia.com/" target="_blank"><img src="{{asset('img/dealer.jpg')}}" alt="Supporting Portal Franchise Bangladesh"></a>
                </li>

                <li>
                    <div class="prtTitle">Partner Portal</div>
                    <a href="https://www.restaurantindia.in/" target="_blank"><img src="{{asset('img/restaurantindia.jpg')}}" alt="Supporting Portal Franchise Bangladesh"></a> 
                </li>         
          </ul>
        </div>
        
      </div>
    </div>
  </div>  
<!--Partner end-->


  @push('scripts')
    <script>
            var slider = tns({
              "container": '.my-Slider1',            
              "responsive": {
                "300": {
                  "items": 1,
                  "mouseDrag": true,
                  
                },
                "500": {
                  "items": 3,
                  "autoplay":true,
                  "autoplayButtonOutput":false
                }
              },
              "swipeAngle": false,
              "speed": 400,
              "nav": false,
              "mouseDrag":true,
              "controls": false,
              "autoplayHoverPause": true,
              "swipeAngle": false,
              "autoplayButtonOutput":false,
              "gutter" : 10,
            });
    </script>

    <script>
            var slider = tns({
              "container": '.my-Slider2',            
              "responsive": {
                "300": {
                  "items": 1,
                  "mouseDrag": true,
                  
                },
                "500": {
                  "items": 4,
                  "autoplay":true,
                  "autoplayButtonOutput":false
                }
              },
              "swipeAngle": false,
              "speed": 400,
              "nav": false,
              "mouseDrag":true,
              "controls": false,
              "autoplayHoverPause": true,
              "swipeAngle": false,
              "autoplayButtonOutput":false,
              
            });
    </script>

    <script>
            var slider = tns({
              "container": '.my-Slider3',            
              "responsive": {
                "300": {
                  "items": 1,
                  "mouseDrag": true,
                  
                },
                "500": {
                  "items": 4,
                  "autoplay":true,
                  "autoplayButtonOutput":false
                }
              },
              "swipeAngle": false,
              "speed": 400,
              "nav": false,
              "mouseDrag":true,
              "controls": false,
              "autoplayHoverPause": true,
              "swipeAngle": false,
              "autoplayButtonOutput":false,
              
            });
    </script>

    <script>
            var slider = tns({
              "container": '.my-Slider4',            
              "responsive": {
                "300": {
                  "items": 1,
                  "mouseDrag": true,
                  
                },
                "500": {
                  "items": 4,
                  "autoplay":true,
                  "autoplayButtonOutput":false
                }
              },
              "swipeAngle": false,
              "speed": 400,
              "nav": false,
              "mouseDrag":true,
              "controls": false,
              "autoplayHoverPause": true,
              "swipeAngle": false,
              "autoplayButtonOutput":false,
              
            });
    </script>
  @endpush

</main>
