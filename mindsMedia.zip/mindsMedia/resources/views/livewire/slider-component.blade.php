<main>

 <!--features start-->
 <section class="u-BoxShadow40  ">
<div class=" ImageBlock ImageBackground__holder my-Slider">
        <div style="background-image: url({{asset('img/awards.jpg')}});">
            <!--<div class="ImageBlock__image col-md- col-sm-4">
                
            </div>-->

            <div class="container testimonials">
                <div class="row">
                    <div class="col-md-8 col-sm-7 exbFull">
                       <h1 class="u-MarginTop0 u-MarginBottom0 u-Weight700 text-white h1">Archex Expo</h1>
                        <h3 class="u-MarginTop10 text-white" style="margin-bottom: 20px;">  <strong>India's Top Most Awards in Franchise</strong>
                        </h3>
                        <p class="text-white mt-3">Franchise &amp; Employee Awards 2022 are India's Topmost Honour in Franchising &amp; 
                            Retailing. COI Awards 2022 highlights those remarkable organizations that have, demonstrated that business 
                            success is more than the sum of its parts. </p>
                <div class="u-MarginTop20 tct">
                       <a class="btn btn-primary text-uppercase u-MarginBottom10 u-LetterSpacing2" href="#" target="_blank">View More</a>
                    </div>
                    </div>
                </div>
            </div>

        </div>

        <div style="background-image: url({{asset('img/awards.jpg')}});">
            <!--<div class="ImageBlock__image col-md- col-sm-4">
                
            </div>-->

            <div class="container testimonials">
                <div class="row">
                    <div class="col-md-8 col-sm-7 exbFull">
                       <h1 class="u-MarginTop0 u-MarginBottom0 u-Weight700 text-white h1">Archex Expo</h1>
                        <h3 class="u-MarginTop10 text-white" style="margin-bottom: 20px;">  <strong>India's Top Most Awards in Franchise</strong>
                        </h3>
                        <p class="text-white mt-3">Franchise &amp; Employee Awards 2022 are India's Topmost Honour in Franchising &amp; 
                            Retailing. COI Awards 2022 highlights those remarkable organizations that have, demonstrated that business 
                            success is more than the sum of its parts. </p>
                <div class="u-MarginTop20 tct">
                       <a class="btn btn-primary text-uppercase u-MarginBottom10 u-LetterSpacing2" href="#" target="_blank">View More</a>
                    </div>
                    </div>
                </div>
            </div>

        </div>

        <div style="background-image: url({{asset('img/awards.jpg')}});">
            <!--<div class="ImageBlock__image col-md- col-sm-4">
                
            </div>-->

            <div class="container testimonials">
                <div class="row">
                    <div class="col-md-8 col-sm-7 exbFull">
                       <h1 class="u-MarginTop0 u-MarginBottom0 u-Weight700 text-white h1">Archex Expo</h1>
                        <h3 class="u-MarginTop10 text-white" style="margin-bottom: 20px;">  <strong>India's Top Most Awards in Franchise</strong>
                        </h3>
                        <p class="text-white mt-3">Franchise &amp; Employee Awards 2022 are India's Topmost Honour in Franchising &amp; 
                            Retailing. COI Awards 2022 highlights those remarkable organizations that have, demonstrated that business 
                            success is more than the sum of its parts. </p>
                <div class="u-MarginTop20 tct">
                       <a class="btn btn-primary text-uppercase u-MarginBottom10 u-LetterSpacing2" href="#" target="_blank">View More</a>
                    </div>
                    </div>
                </div>
            </div>

        </div>
</div>
    </section>
<!--features end-->
 @push('scripts')
    <script>
            var slider = tns({
              "container": '.my-Slider',            
              "responsive": {
                "300": {
                  "items": 1,
                  "mouseDrag": true,
                  
                },
                "500": {
                  "items": 1,
                  "autoplay":true,
                  "autoplayButtonOutput":false
                }
              },
              "swipeAngle": false,
              "speed": 1400,
              "nav": false,
              "mouseDrag":true,
              "controls": false,
              "autoplayHoverPause": true,
              "swipeAngle": false,
              "autoplayButtonOutput":false,
              
            });
    </script>
  @endpush


</main>
