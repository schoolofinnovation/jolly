<?php return array (
  'contact-component' => 'App\\Http\\Livewire\\ContactComponent',
  'footer-component' => 'App\\Http\\Livewire\\FooterComponent',
  'header-component' => 'App\\Http\\Livewire\\HeaderComponent',
  'headernew-component' => 'App\\Http\\Livewire\\HeadernewComponent',
  'home-component' => 'App\\Http\\Livewire\\HomeComponent',
  'media-component' => 'App\\Http\\Livewire\\MediaComponent',
  'overview-component' => 'App\\Http\\Livewire\\OverviewComponent',
  'slider-component' => 'App\\Http\\Livewire\\SliderComponent',
  'sponsership-component' => 'App\\Http\\Livewire\\SponsershipComponent',
);