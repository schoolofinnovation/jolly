<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.4/tiny-slider.css">
    <link href="<?php echo e(asset('assets/css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootsnav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/swiper.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/main.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/font-awesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/pe-icon-7-stroke.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/settings.css')); ?>">

    <!-- REVOLUTION LAYERS STYLES -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/layers.css')); ?>">

    <!-- REVOLUTION NAVIGATION STYLES -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/navigation.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/stylesii.css')); ?>">
    <script src="https://use.fontawesome.com/4f936271bc.js"></script>
    <?php echo \Livewire\Livewire::styles(); ?>

    <style type="text/css">
.testimonials .u-MarginTop10 {
	margin-bottom: 0px;
	margin-top: 25px;
}
.viewagen {
	position: absolute;
	right: 15px;
	top: 30px;
}
.comm {
	background: #000;
}
.btmpadd {
	padding: 40px 0 60px;
	margin-top: 40px;
}
.txtx span {
	display: block;
	float: left;
	text-align: right;
	margin: 13px 0 0 10px;
}
.nppadd {
	padding-left: 0px;
	padding-right: 0px;
}
.bg-darker {
	background: #03408e;
}
.pad60 {
	padding: 40px 0 0px;
}
.socilmedia{float:left;}
.socilmedia ul {
	clear: both;
	margin: 0;
	padding: 0;
	list-style-type: none;
	background: red;
}
.socilmedia ul li {
	float: left;
	margin: -1px 5px 0 0;
	text-align: center;
	width: 38px;
}
.socilmedia ul li:last-child {
	margin: 0;
}
.fa {
	padding-top: 10px;
}
.socilmedia ul li a {
	color: #ed1d24;
	display: block;
	height: 38px;
	border: 2px solid #ed1d24;
	border-radius: 50%;
}
.socilmedia ul li a:hover {
	text-decoration: none;
	color: #fff;
	background: #ed1d24;
}
.socilmedia ul li a.fb {
	background-position: 0 top;
}
.socilmedia ul li a.tt {
	background-position: -39px top;
}
.socilmedia ul li a.in {
	background-position: -80px top;
}
.socilmedia ul li a.fb:hover {
	background-position: 0px -34px;
}
.socilmedia ul li a.tt:hover {
	background-position: -42px -34px;
}
.socilmedia ul li a.in:hover {
	background-position: -80px -34px;
}
nav.navbar.bootsnav .socilmedia {
	z-index: 99;
	display: inline-block;
	float: left;
	margin-top: 14px;
	margin-left:50px;
}
nav navbar-nav navbar-left {
	margin-left: 10px;
}
 @media  screen and (min-width:320px) and (max-width:359px) {
nav.navbar.bootsnav .socilmedia {
	display: none;
}
}
 @media  screen and (min-width:360px) and (max-width:767px) {
nav.navbar.bootsnav .socilmedia {
	margin-right: 0px;
	margin-top: -64px;
}
}
 @media  screen and (min-width:768px) and (max-width:1023px) {
nav.navbar.bootsnav .socilmedia {
	margin-right: 0px;
	margin-top: 48px;
}
.navbar-toggle {
	color: #fff;
}
}
 @media  screen and (min-width:1024px) and (max-width:1199px) {
nav.navbar.bootsnav .socilmedia {
	display: block;
}

nav.navbar.bootsnav ul.nav > li > a {
	font-size: 10px!important;
}
}
</style>

<style type="text/css">
.boxs {
	width: 294px !important;
	padding: 0px 15px !important;
	height: 350px;
}
.boxs .Blurb {
	height: 280px;
}
.u-BoxShadow100 {
	box-shadow: 0 10px 10px rgba(0, 0, 0, 0.1);
}
#spkDemo li {
	width: 294px;
}
p.text-gray {
	font-size: 14px; padding:0px 9px;
}
.u-MarginTop25 {
	margin-top: 10px;
}
 @media (min-width: 300px) and (max-width:359px) {
#spkDemo {
	left: 0px!important;
}
.boxs {
	width: 315px !important;
}
.boxs .Blurb {
	height: auto!important;
}
}
 @media (min-width: 360px) and (max-width:479px) {
#spkDemo {
	left: 0px!important;
}
.boxs {
	width: 330px !important;
}
.boxs .Blurb {
	height: auto!important;
}
}
 @media (min-width: 375px) and (max-width:479px) {
#spkDemo {
	left: 0px!important;
}
.boxs {
	width: 330px !important;
}
.boxs .Blurb {
	height: auto!important;
}
}
 @media (min-width: 480px) and (max-width:599px) {
#spkDemo {
	left: 10px!important;
}
.boxs {
	width: 455px !important;
}
.boxs .Blurb {
	height: auto!important;
}
}
 @media (min-width: 600px) and (max-width:766px) {
#spkDemo {
	left: 10px!important;
}
.boxs {
	width: 580px !important;
}
.boxs .Blurb {
	height: auto!important;
}
}
 @media (min-width: 767px) and (max-width: 979px) {
.boxs {
	width: 375px !important;
}
.boxs .Blurb {
	height: auto!important;
}
}
 @media (min-width: 980px) and (max-width: 1199px) {
#spkDemo {
	left: 20px!important;
}
.boxs {
	width: 385px !important;
	padding: 0px 40px !important;
}
.boxs .Blurb {
	height: auto!important;
}
}
 @media (min-width:1024px) and (max-width:1199px) {
.boxs {
	width: 470px !important;
	padding: 0px 40px !important;
}
}
.text-paragraph, p a, ul.text-paragraph > li, ul.text-paragraph > li > a {
	color: #000;
}
.text-base .Anchors a.text-muted:focus, .text-base .Anchors a.text-muted:hover, p a:active, p a:focus, p a:hover {
	color: #008349;
}
.text-gray a {
	text-decoration: none;
	color: #000;
}
</style>
    <title>Archex</title>
  </head>
  <body>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('headernew-component')->html();
} elseif ($_instance->childHasBeenRendered('9WN8nCx')) {
    $componentId = $_instance->getRenderedChildComponentId('9WN8nCx');
    $componentTag = $_instance->getRenderedChildComponentTagName('9WN8nCx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9WN8nCx');
} else {
    $response = \Livewire\Livewire::mount('headernew-component');
    $html = $response->html();
    $_instance->logRenderedChild('9WN8nCx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php echo e($slot); ?>

   
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer-component')->html();
} elseif ($_instance->childHasBeenRendered('lsoEHkw')) {
    $componentId = $_instance->getRenderedChildComponentId('lsoEHkw');
    $componentTag = $_instance->getRenderedChildComponentTagName('lsoEHkw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lsoEHkw');
} else {
    $response = \Livewire\Livewire::mount('footer-component');
    $html = $response->html();
    $_instance->logRenderedChild('lsoEHkw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    
    <script type="text/javascript" src="<?php echo e(asset('assets/jquery-1.12.2.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/jquery.validate.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/jquery.hint.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/state.js')); ?>"></script> 
    <script type="text/javascript" src="<?php echo e(asset('assets/stateattend.js')); ?>"></script>
    <script src="<?php echo e(asset('js/tiny-slider.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.2/min/tiny-slider.js"></script>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
   
  </body>
</html><?php /**PATH C:\xampp\htdocs\mindsMedia\resources\views/layouts/minds.blade.php ENDPATH**/ ?>