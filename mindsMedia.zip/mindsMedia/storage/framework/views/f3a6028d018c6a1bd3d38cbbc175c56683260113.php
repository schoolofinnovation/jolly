<main>
   <footer class="bg-darker">
      <div class="u-PaddingTop60 u-xs-PaddingTop60 u-PaddingBottom60 u-xs-PaddingBottom30" style="padding-bottom: 0px;">
         <div class="container text-sm">
           
         
            <div class="col-xs-12 col-sm-6 col-md-3 tabsb">
               <h5 class="ftr-head u-MarginTop0">TO EXHIBIT &amp; SPONSORSHIP</h5>
               <!--<div class="ftr-number">Inder</div>-->
                  <div class="ftr-number">+91 740-411-3706</div>
                  <p class="ftr-mail">
                     <a href="mailto:corpcom@councilofinnovation.com">corpcom@councilofinnovation.com</a>
                  </p>
                  <!--<a href="sponsorship-form.php" class="btn btn-primary btn-md conn">Sponsorship Registration</a>-->
            </div>

            <div class="col-xs-12 col-sm-6 col-md-3 tabsb">
               <h5 class="ftr-head u-MarginTop0"> TO ATTEND EXPO, SUMMIT </h5>
               <!--<div class="ftr-name">Mhac</div>-->
                 <div class="ftr-number">+91 958-218-1817</div>   
                     <p class="ftr-mail"> <a href="mailto:visit@councilofinnovation.com">visit@councilofinnovation.com</a></p>
                 <!-- <a href="exhibition_booking_form.php" class="btn btn-primary btn-sm btn-md conn">Exhibition Registration</a>-->
            </div>
   
            <div class="col-xs-12 col-sm-6 col-md-3 tabsb">
               <h5 class="ftr-head u-MarginTop0">FOR AWARDS <br>ENTRIES</h5>
               <div class="ftr-number">+91 740-411-3706</div>
               <p class="ftr-mail"><a href="mailto:team@communityofinnovation.com">team@communityofinnovation.com</a></p>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-3 tabsb">
               <!--<h5 class="ftr-head u-MarginTop0">TO ATTEND SUMMIT</h5>-->
                  <div class="ftr-number">Enquiries</div>
                  <div class="ftr-number">+91 893-800-2235</div>
                  <p class="ftr-mail"> <a href="mailto:attend@councilofinnovation.com">attend@councilofinnovation.com</a></p>
                  <a href="" class="btn btn-sm btn-primary">Registration</a>
            </div>
         
            
         </div>
         <br>
      </div>

      
      <div class="row comm u-MarginTop0 u-PaddingTop30 u-xs-PaddingTop30 u-PaddingBottom100 u-xs-PaddingBottom30" style="padding-bottom: 40px;">
         <div class="container nppadd">
            <div class="col-xs-12 col-sm-6 col-md-6 pull-left no-padding text-left">Copyright © 2013 - 2022 | COI - Community of Innovation</div>
            <div class="col-xs-12 col-sm-6 col-md-3  pull-right no-padding text-right txtx"><span>Powered by:</span> <img src="<?php echo e(asset('img/fi-logo-white.png')); ?>"></div>
         </div>
      </div>
   </footer>
</main><?php /**PATH C:\xampp\htdocs\mindsMedia\resources\views/livewire/footer-component.blade.php ENDPATH**/ ?>