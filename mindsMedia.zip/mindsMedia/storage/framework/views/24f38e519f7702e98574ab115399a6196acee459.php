<main>
    
</main><?php /**PATH C:\xampp\htdocs\mindsMedia\resources\views/livewire/contact-component.blade.php ENDPATH**/ ?>