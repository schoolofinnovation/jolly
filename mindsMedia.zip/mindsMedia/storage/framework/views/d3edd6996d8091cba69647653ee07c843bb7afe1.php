<main>
<section class="ImageBackground ImageBackground--overlay v-align-parent u-height350" data-overlay="5">
        <div class="ImageBackground__holder" style="background-image: url(&quot;assets/imgs/banner/contact.jpg&quot;);">
<img src="<?php echo e(asset('img/contact.jpg')); ?>" alt="">
        </div>
        <div class="v-align-child">
            <div class="container ">
                <div class="row ">
                    <div class="col-md-12 text-white text-center">
                        <h1 class="text-uppercase u-Margin0 u-Weight700">Media Coverage</h1>
                        <ol class="breadcrumb text-white u-MarginTop10 u-MarginBottom0">
                            <li><a href="./">Home</a></li>
                            <li class="active"><span>Media Coverage</span></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
	</section>
</main><?php /**PATH C:\xampp\htdocs\mindsMedia\resources\views/livewire/overview-component.blade.php ENDPATH**/ ?>