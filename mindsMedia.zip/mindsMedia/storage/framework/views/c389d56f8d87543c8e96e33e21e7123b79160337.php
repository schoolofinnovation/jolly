<main>
   <div class="sliderMain  html not-front not-logged-in no-sidebars page-node page-node- page-node-4488 node-type-page domain-adtech loaded">
      <div class="body-container" style="margin-top: 0px"></div>
      <header class="header-container bg-light">
         <div class="header-container-inner">
            <div class="global-content-container">
                                 <div class="header-cta-container">
                                    <a href="#" class="header-cta">
                                       <span class="header-cta-inner">
                                          <span class="cta-secondary">Register Interest Buy Passes</span>
                                          <span class="cta-primary" style="font-size: 1.1em;">To be a part of the event</span>
                                       </span>
                                    </a>
                                    <a href="#" class="header-cta">
                                       <span class="header-cta-inner">
                                          <span class="cta-secondary">Best Exhibition to Exhibit</span>
                                          <span class="cta-primary" style="font-size: 1.1em;">Certified</span>
                                       </span>
                                    </a>
                                    <a href="#" class="header-cta">
                                       <span class="header-cta-inner">
                                          <span class="cta-secondary">For sponsorship and exhibiting opportunities</span>
                                          <span class="cta-primary" style="font-size: 1.1em;">Contact</span>
                                       </span>
                                    </a>
                                 </div>
            
                                 <div class="secondary-navigation-container">
                                    <div class="custom-links">
                                       <a style="padding: 0px;" target="_blank" href="#" data-type="twitter"><i class="bi bi-twtter"></i></a>
                                       <a style="padding: 0px;" target="_blank" href="#" data-type="facebook"><span> <i class="bi bi-facebook text-center"></i> </span></a>
                                       <a style="padding: 0px;" target="_blank" href="#" data-type="linkedin">&nbsp;<span></span></a>
                                       <a style="padding: 0px;" data-type="made" href="#" target="_blank"><span></span></a>
                                       <a style="padding: 0px;" href="#" data-type="custom">Floor Plan</a>
                                    </div>
                                 </div>

                                 <div class="primary-navigation-container">
                                    <ul>
                                       <li class="expanded">
                                             <span title="" class="nolink has-children" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                                                About
                                             <span class="mobile-arrow"></span>
                                            
                                             </span>
                                          <ul>
                                             
                                             <li style = "padding : 3px; "><a href="#" title="">WHAT IS Archex, Jammu?</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Who Attends?</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Contact Us</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Register for Space</a></li>
                                             
                                          </ul>
                                       </li>

                                       <li class="expanded">
                                          <span title="" class="nolink has-children" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                                          COI Awards<span class="mobile-arrow">
                                          </span>
                                          <span class="mobile-arrow"></span>
                                          </span>
                                          <ul>
                                             <li style = "padding : 3px; "><a href="#" title="">2022 THEME</a></li>
                                             <li class="expanded">
                                                <a href="#" title="" class="has-children" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                                                   Agenda<span class="mobile-arrow"></span>
                                                        
                                                </a>
                                                <ul>
                                                   <li style = "padding : 3px; "><a href="#" title="">Day 1: Appreciate your Partners</a></li>
                                                   <li style = "padding : 3px; "><a href="#" title="">Day 2: Certify Your Employees</a></li>
                                                </ul>
                                             </li>
                                             <li style = "padding : 3px; "><a href="#" title="">SPEAKERS</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Call for Speakers</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Nominate</a></li>
                                          </ul>
                                       </li>

                                       <li class="expanded">
                                          <span title="" class="nolink has-children" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                                             Sponsors &amp; Exhibitors 
                                             <span class="mobile-arrow"></span>
                                             
                                          </span>
                                          <ul>
                                             <li style = "padding : 3px; "><a href="#" title="">Food & Beverages</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Brochure Opportunities</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Print Media Opportunities</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Travel Opportunities</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Partner Programs</a></li>
                                          </ul>
                                       </li>

                                       <li class="expanded">
                                          <span title="" class="nolink has-children" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                                             Meet-ups 
                                             <span class="mobile-arrow"></span>
                                            
                                          </span>
                                          <ul>
                                             <li style = "padding : 3px; "><a href="#" title="">Corporate Meet</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Dealer Meet</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Business Meet</a></li>
                                          </ul>
                                       </li>
                                    </ul>      
                                 </div>

               <!--mobile view-->
                  <div class="main-group">
                     <div class="logo-container">
                        <div class="logo-primary"><a href="" title="Home">
                           <img src="<?php echo e(asset('img/fro-expo.png')); ?>" alt="MindsMedia"></a>
                        </div>
                        <div class="logo-tertiary">Performance &amp; Innovation</div>
                        <div class="logo-secondary" style="margin-top: 25px;">25-28 Nov 2022
                              
                              <span class="break">
                                    <div class="field field-name-field-event-location field-type-text"> Jammu, India</div>
                              </span>
                        </div>
                     </div>

                     <div class="mobile-menu-button" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                     Menu</div>
                                    <ul class="mobile-menu-button" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                     Menu
                                       <li class="expanded">
                                             <span title="" class="nolink has-children" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                                                About
                                             <span class="mobile-arrow"></span>
                                            
                                             </span>
                                          <ul>
                                             
                                             <li style = "padding : 3px; "><a href="#" title="">WHAT IS Archex, Jammu?</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Who Attends?</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Contact Us</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Register for Space</a></li>
                                             
                                          </ul>
                                       </li>

                                       <li class="expanded">
                                          <span title="" class="nolink has-children" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                                          COI Awards<span class="mobile-arrow">
                                          </span>
                                          <span class="mobile-arrow"></span>
                                          </span>
                                          <ul>
                                             <li style = "padding : 3px; "><a href="#" title="">2022 THEME</a></li>
                                             <li class="expanded">
                                                <a href="#" title="" class="has-children" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                                                   Agenda<span class="mobile-arrow"></span>
                                                        
                                                </a>
                                                <ul>
                                                   <li style = "padding : 3px; "><a href="#" title="">Day 1: Appreciate your Partners</a></li>
                                                   <li style = "padding : 3px; "><a href="#" title="">Day 2: Certify Your Employees</a></li>
                                                </ul>
                                             </li>
                                             <li style = "padding : 3px; "><a href="#" title="">SPEAKERS</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Call for Speakers</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Nominate</a></li>
                                          </ul>
                                       </li>

                                       <li class="expanded">
                                          <span title="" class="nolink has-children" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                                             Sponsors &amp; Exhibitors 
                                             <span class="mobile-arrow"></span>
                                             
                                          </span>
                                          <ul>
                                             <li style = "padding : 3px; "><a href="#" title="">Food & Beverages</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Brochure Opportunities</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Print Media Opportunities</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Travel Opportunities</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Partner Programs</a></li>
                                          </ul>
                                       </li>

                                       <li class="expanded">
                                          <span title="" class="nolink has-children" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);">
                                             Meet-ups 
                                             <span class="mobile-arrow"></span>
                                            
                                          </span>
                                          <ul>
                                             <li style = "padding : 3px; "><a href="#" title="">Corporate Meet</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Dealer Meet</a></li>
                                             <li style = "padding : 3px; "><a href="#" title="">Business Meet</a></li>
                                          </ul>
                                       </li>
                                    </ul>      

                     
                  </div>
               <!--mobile view-->

            </div>
         </div>
      </header>

      <div class="page-container">
         <div class="mobile-header-cta-container count-3">
            <a href="#" class="mobile-header-cta">
               <span class="header-cta-inner">
               <span class="cta-secondary">Virtual</span>
               <span class="cta-primary">events</span>
               </span>
            </a>
            <a href="#" class="mobile-header-cta">
               <span class="header-cta-inner">
               <span class="cta-secondary">Adtech</span>
               <span class="cta-primary">News</span>
               </span>
            </a>
            <a href="#" class="mobile-header-cta">
               <span class="header-cta-inner">
               <span class="cta-secondary">For sponsorship and exhibiting opportunities</span>
               <span class="cta-primary">Contact Us</span>
               </span>
            </a>
         </div>
      </div>
   </div>
</main><?php /**PATH C:\xampp\htdocs\mindsMedia\resources\views/livewire/headernew-component.blade.php ENDPATH**/ ?>