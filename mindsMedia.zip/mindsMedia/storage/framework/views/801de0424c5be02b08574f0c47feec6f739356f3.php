<main>
   <div class="sticky-wrapper" style="height: 0px;">
      <header id="header" class="Sticky headroom Sticky--stuck headroom--not-bottom Sticky--pinned Sticky--top"> 
         <!-- Start Navigation -->
         <nav class="navbar navbar-default navbar-fixed white bootsnav on no-full no-background">
            <div class="container"> 
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu"> 
                  <i class="bi bi-list"></i> </button>
                  <a class="navbar-brand" href="#"> <img src="<?php echo e(asset('img/fro-expo.png')); ?>" class="logo logo-display" alt=""> 
                  <img src="<?php echo e(asset('img/fro-expo(1).png')); ?>" class="logo logo-scrolled" alt=""> </a> 
               </div>
            
               <!-- Start Atribute Navigation --> 
               <div class="mainHead">
                  <div class="topMain">
                     <div class="socilmedia">
                        <ul>
                           <li><a target="_blank" href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                           <li><a target="_blank" href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                           <li><a target="_blank" class="in" href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                           <li><a target="_blank" class="in" href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                        </ul>
                     </div>
                     <!--<div class="bos-sec">
                           <div class="bosTp">
                           <h3><span>For More</span> <strong>Business Opportunities</strong><br>
                           Visit - <a href="https://www.franchiseindia.com/?utm_source=fro%20campaign&utm_medium=slug">www.franchiseindia.com</a></h3>
                           </div>
                        </div> -->
                  </div>
               </div>

               <div class="collapse navbar-collapse" id="navbar-menu">
                     <ul class="nav navbar-nav navbar-left txtwhite" data-in="" data-out="">
                           <li class="dropdown"> <a href="#" class="dropdown-toggle2" data-toggle="dropdown">Exhibition </a>
                              <ul class="dropdown-menu animated" style="display: none; opacity: 1;">
                                 <li><a href="#">Overview</a></li>
                                 <li><a href="#">Exhibitors</a></li>
                                 <li><a href="#">Exhibition Registration</a></li>
                                 <li><a href="#">Floor Plan</a></li>
                              </ul>
                           </li>
                           <li> <a href="#" target="_blank">Awards</a> </li>                  
                           <li> <a href="#">Partners</a></li>
                           <li> <a href="#">Media</a></li>
                           <li> <a href="#">Contact Us</a></li>
                     </ul>

                     <div class="attr-nav">
                        <ul>
                           <li class="buy-btn hidden-xs hidden-sm"><a href="#" data-modal-link="email-ticket">
                           <span class="btn btn-sm btn-primary n-MarginTop5 text-uppercase regNow">Register Now</span></a></li>
                        </ul>
                     </div>
               </div>  
            </div>
         </nav>
         <!-- End Navigation -->
         <div class="clearfix"></div>
      </header>
   </div>
</main><?php /**PATH C:\xampp\htdocs\mindsMedia\resources\views/livewire/header-component.blade.php ENDPATH**/ ?>