<?php

namespace App\Http\Livewire;

use Livewire\Component;

class OverviewComponent extends Component
{
    public function render()
    {
        return view('livewire.overview-component')->layout('layouts.minds');
    }
}
