<?php

use App\Http\Livewire\ContactComponent;
use App\Http\Livewire\HomeComponent;
use App\Http\Livewire\MediaComponent;
use App\Http\Livewire\OverviewComponent;
use App\Http\Livewire\SponsershipComponent;
use Illuminate\Support\Facades\Route;


Route::get('/', HomeComponent::class)->name('minds.home');

Route::get('/media', MediaComponent::class)->name('minds.media');
Route::get('/overview', OverviewComponent::class)->name('minds.overview');
Route::get('/Sponsership', SponsershipComponent::class)->name('minds.sponsership');
Route::get('/Contact', ContactComponent::class)->name('minds.contact');